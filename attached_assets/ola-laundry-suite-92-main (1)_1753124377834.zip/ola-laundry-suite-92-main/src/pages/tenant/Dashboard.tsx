
import { EnhancedDashboard } from "@/components/dashboard/EnhancedDashboard";

export default function TenantDashboard() {
  return <EnhancedDashboard />;
}
