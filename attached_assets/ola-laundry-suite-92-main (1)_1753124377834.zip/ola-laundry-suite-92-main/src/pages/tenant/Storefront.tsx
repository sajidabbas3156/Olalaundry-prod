
import { EnhancedStorefrontMain } from "@/components/storefront/EnhancedStorefrontMain";

export default function TenantStorefront() {
  return <EnhancedStorefrontMain />;
}
