import { DeliveryDriverApp } from "@/components/mobile/DeliveryDriverApp";

export default function DeliveryApp() {
  return <DeliveryDriverApp />;
}