import { CustomerMobileApp } from "@/components/mobile/CustomerMobileApp";

export default function CustomerApp() {
  return <CustomerMobileApp />;
}