
import { MobileNavigation } from "./MobileNavigation";

// Legacy component - redirects to new unified MobileNavigation
export function AdvancedMobileNavigation() {
  return <MobileNavigation />;
}
